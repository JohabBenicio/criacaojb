-- -----------------------------------------------------------------------------------
-- Autor               : Giovani Marinho e Johab Benicio
-- Descrição           : Ativar geracao de trace ao conectar.
-- Nome do arquivo     : TriggerTrace.sql
-- Data de criação     : ??????????
-- Data de atualização : 05/04/2016
-- -----------------------------------------------------------------------------------

##############################################################################################################################
## Passo 0: Detalhes
##############################################################################################################################

-- Gerar o DDL da trigger.

SET LONG 99999 LINES 200 PAGES 300
SELECT DBMS_METADATA.GET_DDL('TRIGGER', 'TRG_LOGON_10046_JB', 'SYS' ) txt FROM DUAL;


-- Analisar Status da trigger.

select OWNER,TRIGGER_NAME,STATUS from dba_triggers where upper(TRIGGER_NAME) like 'TRG_LOGON_10046%';


-- Desabilitar Trigger

alter trigger sys.trg_logon_10046_jb disable;


-- Habilitar trigger

alter trigger sys.trg_logon_10046_jb enable;





##############################################################################################################################
## Passo 1: Criar tabela
##############################################################################################################################

desc sys.traceflag

drop table sys.traceflag ;

create table sys.traceflag
(
  flag number not null constraint ck_flag check (flag in (0, 1)),
  tipo number not null constraint ck_tipo check (tipo in (0, 1, 2, 3)),
  campo varchar2(50) not null,
  descricao varchar2(50) null
);


grant all on sys.traceflag to public;

create public synonym traceflag for sys.traceflag;

grant alter session to public;



##############################################################################################################################
## Passo 2: Criar Trigger
##############################################################################################################################

create or replace trigger sys.trg_logon_10046_jb after logon on database
declare
  v_count number;
  v_identifier varchar(64);
begin

for x in (select * from sys.traceflag where flag=1) loop

CASE x.tipo
  WHEN 0 THEN
    select count(0), upper(sys_context('userenv', 'session_user')) || '_' || trim(to_char(sysdate, 'yyyymmddhh24miss')) into v_count, v_identifier
    from sys.traceflag where upper(campo) = upper(sys_context('userenv', 'session_user'));
  WHEN 1 THEN
    select count(0), upper(sys_context('userenv', 'os_user')) || '_' || trim(to_char(sysdate, 'yyyymmddhh24miss')) into v_count, v_identifier
    from sys.traceflag where upper(campo) = upper(sys_context('userenv', 'os_user'));
  WHEN 2 THEN
    select count(0), upper(sys_context('userenv', 'session_user')) || '_' || trim(to_char(sysdate, 'yyyymmddhh24miss')) into v_count, v_identifier
    from sys.traceflag where upper(campo) = upper(sys_context('userenv', 'terminal'));
  WHEN 3 THEN
    select count(0), upper(sys_context('userenv', 'session_user')) || '_' || trim(to_char(sysdate, 'yyyymmddhh24miss')) into v_count, v_identifier
    from sys.traceflag where upper(campo) = upper(sys_context('userenv', 'host'));
END CASE;

end loop;

if v_count > 0 then
  execute immediate 'alter session set statistics_level = all';
  execute immediate 'alter session set timed_statistics = true';

  begin
    execute immediate 'alter session set tracefile_identifier = TEOR_' || v_identifier;
  exception
    when others then
      null;
  end;

  execute immediate 'alter session set max_dump_file_size = unlimited';
  execute immediate 'alter session set events ' || chr(39) || '10046 trace name context forever, level 12' || chr(39);
end if;

end;
/




##############################################################################################################################
## Passo 3: Configurar gatilho de trace.
##############################################################################################################################
# TIPO
0 = USERNAME
1 = OSUSER
2 = TERMINAL
3 = HOST


define flag=1
define tipo=0
define campo=12529
define descricao='Chamado 51878'

define flag=0
define tipo=0
define campo=ODHO_C
define descricao='Chamado 50799 - 1'

define flag=1
define tipo=1
define campo=lsreal
define descricao='Chamado 51349'



-- Inserindo dados de usuario que vai ser rastreado.

delete sys.traceflag ;
commit;


insert into sys.traceflag (flag,tipo,campo,descricao) values (&&flag,&&tipo,'&&campo','&&descricao');
commit;






select sid,serial#,inst_id,osuser,machine,terminal,program from gv$session where osuser='GR156300';


-- Ativando o rastreamento

update sys.traceflag set flag=1 where campo='&&campo' and flag=0 and descricao='&&descricao';
commit;

-- Desativar o rastreamento

update sys.traceflag set flag=0 where campo='&&campo' and flag=1 and descricao='&&descricao';
commit;


set lines 200
select * from sys.traceflag;



##############################################################################################################################
## Passo 4: Identificar sessão no banco de dados
##############################################################################################################################

define campo=cjunior


col LOGON_TIME for a20
col machine for a30
col username for a15
col osuser for a15
col terminal for a15
col KILL_SESSION for a55
col TRACEFILE for a200
col event for a30
set lines 300 pages 300
select distinct s.sql_id,s.username,s.program,s.machine,s.terminal,s.sid,s.serial#,s.osuser,s.inst_id,to_char(s.LOGON_TIME,'dd/mm/yyyy hh24:mi') LOGON_TIME,s.status,round(s.last_call_et/60) TimeMin ,s.EVENT, 'alter system kill session '''||s.sid||','||s.serial#||',@'||s.inst_id||''' immediate;' KILL_SESSION
from gv$session s, gv$process p
where (upper(s.osuser)=upper('&&campo') or upper(s.username)=upper('&&campo') or upper(s.terminal)=upper('&&campo') or upper(machine)=upper('&&campo'))
and p.addr = s.paddr
order by 5;




define campo=usr_process

col LOGON_TIME for a20
col machine for a30
col username for a15
col osuser for a15
col terminal for a15
col KILL_SESSION for a55
col TRACEFILE for a200
col event for a30
set lines 300 pages 300
select distinct s.sql_id,s.username,s.program,s.machine,s.terminal,s.sid,s.serial#,s.osuser,s.inst_id,to_char(s.LOGON_TIME,'dd/mm/yyyy hh24:mi') LOGON_TIME,s.status,round(s.last_call_et/60) TimeMin ,s.EVENT
from gv$session s, gv$process p
where (upper(s.osuser)=upper('&&campo') or upper(s.username)=upper('&&campo') or upper(s.terminal)=upper('&&campo') or upper(machine)=upper('&&campo'))
and p.addr = s.paddr
and s.program='PSipAns.exe'
order by 5;






col LOGON_TIME for a20
col machine for a30
col username for a15
col osuser for a15
col terminal for a15
col KILL_SESSION for a55
col TRACEFILE for a200
col event for a30
set lines 300 pages 300
select distinct s.sql_id,s.username,s.machine,s.terminal,s.sid,s.serial#,s.osuser,s.inst_id,to_char(s.LOGON_TIME,'dd/mm/yyyy hh24:mi') LOGON_TIME,s.status,round(s.last_call_et/60) TimeMin,s.EVENT, 'alter system kill session '''||s.sid||','||s.serial#||',@'||s.inst_id||''' immediate;' KILL_SESSION
from gv$session s, gv$process p
where s.sid=1528
order by 5;




col LOGON_TIME for a20
col machine for a30
col username for a15
col osuser for a20
col terminal for a15
col KILL_SESSION for a55
col TRACEFILE for a100
col spid for 9999999
set lines 300 pages 300
select s.username,s.machine,s.sid,s.serial#,s.osuser,s.inst_id,to_char(s.LOGON_TIME,'dd/mm/yyyy hh24:mi') LOGON_TIME,s.status,spid,TRACEFILE
from gv$session s, gv$process p
where (upper(s.osuser)=upper('&&campo') or upper(s.username)=upper('&&campo') or upper(s.terminal)=upper('&&campo') or upper(machine)=upper('&&campo'))
and p.addr = s.paddr
order by 5;




col LOGON_TIME for a20
col machine for a30
col username for a15
col osuser for a20
col terminal for a15
col KILL_SESSION for a55
col TRACEFILE for a100
col spid for 9999999
set lines 300 pages 300

begin

for x in (select s.username,s.machine,s.sid,s.serial#,s.osuser,s.inst_id,to_char(s.LOGON_TIME,'dd/mm/yyyy hh24:mi') LOGON_TIME,s.status,spid,TRACEFILE
from gv$session s, gv$process p
where (upper(s.osuser)=upper('&&campo') or upper(s.username)=upper('&&campo') or upper(s.terminal)=upper('&&campo') or upper(machine)=upper('&&campo'))
and p.addr = s.paddr
order by 5) loop

end loop;
dbms_output.put_line

end;
/









##############################################################################################################################
## Encontrar sessão do cliente no banco de dados
##############################################################################################################################

define campo=oracle


col LOGON_TIME for a20
col machine for a30
col username for a15
col osuser for a15
col terminal for a15
col KILL_SESSION for a55
col TRACEFILE for a200
col event for a30
set lines 300 pages 300
select s.sql_id,s.username,s.machine,s.terminal,s.sid,s.serial#,s.osuser,s.inst_id,to_char(s.LOGON_TIME,'dd/mm/yyyy hh24:mi') LOGON_TIME,s.status,round(s.last_call_et/60) TimeMin,p.spid,s.EVENT, 'alter system kill session '''||s.sid||','||s.serial#||',@'||s.inst_id||''' immediate;' KILL_SESSION
from gv$session s, gv$process p
where (upper(s.osuser)=upper('&&campo') or upper(s.username)=upper('&&campo') or upper(s.terminal)=upper('&&campo') or upper(machine)=upper('&&campo'))
and p.addr = s.paddr and s.username is not null
order by 5;




col LOGON_TIME for a20
col machine for a30
col username for a15
col osuser for a15
col terminal for a15
col KILL_SESSION for a55
col TRACEFILE for a200
col event for a30
set lines 300 pages 300
select s.sql_id,s.username,s.machine,s.terminal,s.sid,s.serial#,s.osuser,s.inst_id,to_char(s.LOGON_TIME,'dd/mm/yyyy hh24:mi') LOGON_TIME,s.status,round(s.last_call_et/60) TimeMin,p.spid,s.EVENT, 'alter system kill session '''||s.sid||','||s.serial#||',@'||s.inst_id||''' immediate;' KILL_SESSION
from gv$session s, gv$process p
where (upper(s.osuser)=upper('&&campo') or upper(s.username)=upper('&&campo') or upper(s.terminal)=upper('&&campo') or upper(machine)=upper('&&campo'))
and p.addr = s.paddr and s.username is not null
order by 5;







##############################################################################################################################
## Passo 5: Identificar os traces no S.O.
##############################################################################################################################

find $ORACLE_BASE -name "*TEOR*" -mmin -60 -exec ls -lh {} \;

find  -name *TEOR* -mmin +60 -exec ls -lh {} \;

find  -name "*USR_PROCESS*" -mmin +60 -exec ls -lh {} \;
find  -name "*usr_process*" -mmin +60 -exec ls -lh {} \;



