Horário de verão

zdump -v /etc/localtime | grep `date +"%Y"`

/etc/localtime  Sun Feb 22 01:59:59 2015 UTC = Sat Feb 21 23:59:59 2015 BRST isdst=1 gmtoff=-7200
/etc/localtime  Sun Feb 22 02:00:00 2015 UTC = Sat Feb 21 23:00:00 2015 BRT isdst=0 gmtoff=-10800
/etc/localtime  Sun Oct 18 02:59:59 2015 UTC = Sat Oct 17 23:59:59 2015 BRT isdst=0 gmtoff=-10800
/etc/localtime  Sun Oct 18 03:00:00 2015 UTC = Sun Oct 18 01:00:00 2015 BRST isdst=1 gmtoff=-7200


Analise se a data esta correta, caso não esteja, faça o seguinte procedimento.

rm -f /tmp/verao.zic
vi /tmp/verao.zic
i

Rule Brazil 2016 only - Feb 21 00:00 0 -
Rule Brazil 2016 only - Oct 16 00:00 1 S
Rule Brazil 2017 only - Feb 19 00:00 0 -
Rule Brazil 2017 only - Oct 22 00:00 1 S
Rule Brazil 2018 only - Feb 18 00:00 0 -
Rule Brazil 2018 only - Oct 21 00:00 1 S
Rule Brazil 2019 only - Feb 17 00:00 0 -
Rule Brazil 2019 only - Oct 20 00:00 1 S
Rule Brazil 2020 only - Feb 16 00:00 0 -
Rule Brazil 2020 only - Oct 18 00:00 1 S
Zone Brazil/East -3:00 Brazil BR%sT

:wq!


zic /tmp/verao.zic

cp /etc/localtime /etc/localtime_`date +"%Y"`.bkp

rm -f /etc/localtime

cp /usr/share/zoneinfo/Brazil/East /etc/localtime

G


/etc/init.d/crond restart

ou

/etc/init.d/cron restart



 (17) 997-751-093