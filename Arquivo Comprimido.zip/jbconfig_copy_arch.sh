
rm -f /tmp/jbconfig_copy_arch.sh

vi /tmp/jbconfig_copy_arch.sh
i

#!/bin/bash

clear


export NLS_LANG="AMERICAN_AMERICA.WE8ISO8859P1"
readonly ODU_COLOR_NORM="\033[0m"
readonly ODU_COLOR_BOLD="\033[1m"
readonly ODU_COLOR_GREEN="\033[1;32;40m"
readonly ODU_COLOR_RED="\033[1;31;40m"

export MSG_SUCESSO="$ODU_COLOR_BOLD$ODU_COLOR_GREEN"Ok"$ODU_COLOR_NORM"
export MSG_FALHA="$ODU_COLOR_BOLD$ODU_COLOR_RED"Falha"$ODU_COLOR_NORM"
export MSG_FINALIZADO="$ODU_COLOR_BOLD$ODU_COLOR_GREEN"FINALIZADO"$ODU_COLOR_NORM"

echo -e "\n"
ps -ef | grep smon | grep -v grep | awk '{print $NF}'
echo -e "\n"

read -p "Informe o nome da instancia: " ORACLE_SID

cat /etc/hosts | grep "192\|168\|10"

read -p "Informe o IP do servidor de standby: " STDB_IP

if [ -d "$ORACLE_BASE/admin/$ORACLE_SID/scripts" ]; then
  export STDB_BASE=$ORACLE_BASE/admin/$ORACLE_SID/scripts
  mkdir -p $STDB_BASE/standby/log
  export STDB_HOME=$STDB_BASE/standby

elif [ -d "$ORACLE_BASE/admin/$ORACLE_SID/script" ]; then
  export STDB_BASE=$ORACLE_BASE/admin/$ORACLE_SID/script
  mkdir -p $STDB_BASE/standby/log
  export STDB_HOME=$STDB_BASE/standby

elif [ -d "$ORACLE_BASE/admin/$ORACLE_SID" ]; then
  mkdir -p $ORACLE_BASE/admin/$ORACLE_SID/scripts
  export STDB_BASE=$ORACLE_BASE/admin/$ORACLE_SID/scripts
  mkdir -p $STDB_BASE/standby/log
  export STDB_HOME=$STDB_BASE/standby

else
  read -p "Informe o diretório onde será armazenado os scripts do standby: " STDB_HOME
  if [ ! -d "$STDB_HOME" ]; then echo -e "\n\nEste diretorio nao existe! \n\n"; exit; fi

fi

mkdir $STDB_HOME/lock 2>>/dev/null

read -p "Informe o diretório onde os archives irão ser geradas no [ SERVIDOR DE PRODUÇÃO ]: " DIR_BKP

if [ ! -d "$DIR_BKP" ]; then echo -e "\n\nEste diretorio nao existe! \n\n"; exit; fi

read -p "Informe o diretório onde os archives irão ser armazenado no [ SERVIDOR DE STANDBY ] : " STDB_DIR_BKP

echo -e "\n\n"
printf "%-90s" "Criação do script de transferencia dos archives."

cat <<EOF> $STDB_HOME/ExCopArch.sh

#!/bin/bash
# Teor Tecnologia Orientada
# Rua Carneiro da Cunha, 167 - cj. 105
# (11) 3797-8299
# São Paulo - SP
#
# Atualizado em 24/10/2014
#
# Efetua copia dos archives no standby
#
# Versao para Linux
# $1 ORACLE_SID

#
# Inicio
#

#-- -------------------------------------------------------------------------------
#-- Carregar variaveis do bash_profile
#-- -------------------------------------------------------------------------------

if [ -f ~/.bash_profile ]; then
. ~/.bash_profile;
elif [ ~/.profile ]; then
. ~/.profile
fi

#-- -------------------------------------------------------------------------------
#-- Local onde os scripts estao no servidor
#-- -------------------------------------------------------------------------------
export STDB_HOME=$STDB_HOME

#-- -------------------------------------------------------------------------------
#-- Analisar se instancia esta no ar
#-- -------------------------------------------------------------------------------
BANCO=\`ps -ef | grep smon | grep \$1 2>>/dev/null | sed 's/.*mon_\(.*\)\\\$/\1/' | grep -E "(^| )\$1( |\$)"\`

if [ -z "\$1" ]; then
   echo "Digite: sh ExCopArch.sh <SID> ou ExCopArch.sh <SID>" ;
   exit

elif [ "\$BANCO" = "\$1" ]; then
   export ORACLE_SID=\$1

else
   echo "Banco nao existe" ;
   exit

fi

#-- -------------------------------------------------------------------------------
#-- IP do servidor de standby
#-- -------------------------------------------------------------------------------
export STDB_IP=$STDB_IP

#-- -------------------------------------------------------------------------------
#-- Log da copia das pecas de backup
#-- -------------------------------------------------------------------------------
export STDB_DATA=\`date +%d%m%Y_%T\`
export STDB_LOG=\$STDB_HOME/log/copia_archive_\$ORACLE_SID\_\$STDB_DATA.log

#-- -------------------------------------------------------------------------------
#-- Local das pecas de backup/archive Producao
#-- -------------------------------------------------------------------------------
export DIR_BKP="$DIR_BKP"
export FIND_DIR="\$DIR_BKP -name arc* -perm 640 -mmin +1"


#-- -------------------------------------------------------------------------------
#-- Local onde vai ser tranferido as pecas no servidor de standby
#-- -------------------------------------------------------------------------------
export STDB_DIR_BKP=$STDB_DIR_BKP

#-- -------------------------------------------------------------------------------
#-- Caracter set do S.O.
#-- -------------------------------------------------------------------------------
export NLS_LANG="AMERICAN_AMERICA.WE8ISO8859P1"

#-- -------------------------------------------------------------------------------
#-- Analisar se o processo de copia esta em execucao
#-- -------------------------------------------------------------------------------
export STDB_STAT=\$(ps -ef | grep "\$STDB_IP:\$STDB_DIR_BKP\|\$STDB_IP \$STDB_DIR_BKP" | grep -v grep | wc -l)

if [ "\$STDB_STAT" -eq "0" ]
then


HEADER=`find \$FIND_DIR | wc -l`

if [ "\$HEADER" -gt "0" ]
then
   echo ". Copiando archives para o servidor StandBy (\$STDB_IP) ..." >> \$STDB_HOME/log/copia_archive_\$ORACLE_SID.log

   find \$FIND_DIR | while read arquivo
   do
      echo -n "\$arquivo -> \$STDB_IP... "

         scp \$arquivo \$STDB_IP:\$STDB_DIR_BKP

         if [ "\$?" -eq "0" ]
         then
            HOR_EXEC=\`date\`
            chmod 644 \$arquivo
            echo "\$arquivo -> \$STDB_IP, Ok. -- \$HOR_EXEC" >> \$STDB_HOME/log/copia_archive_\$ORACLE_SID.log
            echo " Ok. -- \$HOR_EXEC ."
         else
            HOR_EXEC=\`date\`
            echo "\$arquivo -> \$STDB_IP, ERRO.  -- \$HOR_EXEC" >> \$STDB_HOME/log/copia_archive_\$ORACLE_SID\_erro.log
            echo " ERRO.  -- \$HOR_EXEC ."
            exit
         fi

   done
else
   HOR_EXEC=\`date\`
   echo "Neste momento nao existe novas pecas de backup -- \$HOR_EXEC" >> \$STDB_HOME/log/copia_archive_\$ORACLE_SID\_none.log
   exit
fi

fi


exit



EOF



if [ "$?" -eq "0" ]; then echo -e "[    $MSG_SUCESSO    ]"; else echo -e "[   $MSG_FALHA  ]"; fi




chmod 775 $STDB_HOME/ExCopArch.sh



cat <<EOF


#+------------------------------------------------------------------------------------------------------------------------------+
## COPIA DOS ARCHIVES PARA STANDBY                                                                                              |
#+------------------------------------------------------------------------------------------------------------------------------+
# BANCO $ORACLE_SID
#+------------------------------------------------------------------------------------------------------------------------------+
# Minute Hour  MonthDay Month  Weekday Command
# ------ ----- -------- ------ ------- -----------------------------------------------------------------------------------------+
  */35   *     *        *      *       $STDB_HOME/ExCopArch.sh $ORACLE_SID 1>/dev/null 2>/dev/null




EOF


:wq!

sh /tmp/jbconfig_copy_arch.sh
