alias unimedpp="echo -e \"\n oracle = uni@ora*360 \n root = unid&ago \n \"; teor"


alias caltabiano="echo -e \"\n root = C@ltab1@n0!r00T \n oracle = C@ltab1@n0!Or@cl3 \n \"; teor"


read -p "informe o alias que ira chamar o acesso: " ALCLI
read -p "O acesso vai ser direto? Sim (1) " AC


if [ $AC = 1 ]; then
read -p ""

else

fi