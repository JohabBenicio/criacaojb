 w | grep -vi "load average\|USER     TTY" | awk '{print "echo \"Favor entrar em contato com a TEOR -> (11) 976-362-548\">>/dev/"$2 }' | bash
