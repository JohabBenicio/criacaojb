PECA=full
VTEM=7

find  *$PECA*.log -mtime -$VTEM | while read arch
do
VALID=$(cat $arch | grep "ORA-\|RMAN-" | grep -v "grep\|WARNING" | wc -l)
if [ "$VALID" -gt "0" ]; then
ls -lthr $arch
fi
done





VTEM=3
find -name "*.log" -mtime -$VTEM | while read log
do
VALID=$(cat $log | grep "ORA-\|RMAN-" | grep -v grep | wc -l)
if [ "$VALID" -gt "0" ]; then
ls -lthr $log
fi;
done












A abertura deste incidente ocorreu devido as atividades realizadas no chamado "47188 - Horario de verão".
Estamos encaminhando este chamado para o encerramento.

Atenciosamente,
Johab Benício de Oliveira.










AÇÕES EXECUTADAS (resumo)
=========================
1) - Analise de logs;
* Não detectamos nenhum erro nos logs de backup.

Obs.: Com base nos dados do log, seu backup foi concluido com sucesso.
Estamos encaminhando este chamado para o encerramento.

DADOS COLETADOS
===============
-rw-r--r-- 1 oracle oinstall 143477 Feb 21 02:13 /backup/dw/logico/expdp_full_dw1_0_210216.log

Master table "SYS"."SYS_EXPORT_FULL_01" successfully loaded/unloaded
******************************************************************************
Dump file set for SYS.SYS_EXPORT_FULL_01 is:
  /backup/dw/logico/expdp_full_dw1_0_210216_01.dmp
  /backup/dw/logico/expdp_full_dw1_0_210216_02.dmp
  /backup/dw/logico/expdp_full_dw1_0_210216_03.dmp
  /backup/dw/logico/expdp_full_dw1_0_210216_04.dmp
  /backup/dw/logico/expdp_full_dw1_0_210216_05.dmp
  /backup/dw/logico/expdp_full_dw1_0_210216_06.dmp
Job "SYS"."SYS_EXPORT_FULL_01" successfully completed at Sun Feb 21 02:13:13 2016 elapsed 0 00:08:10


Att,
Johab Benicio
DBA Oracle.





AÇÕES EXECUTADAS (resumo)
========================
1) - Analise de logs.

CAUSA
======
A abertura deste incidente ocorreu devido as atividades realizadas no chamado "47188 - Horario de verão".
Estamos encaminhando este chamado para o encerramento.

DADOS COLETADOS
================
1) - Ultimo log de backup.

Master table "SYS"."SYS_EXPORT_FULL_01" successfully loaded/unloaded
******************************************************************************
Dump file set for SYS.SYS_EXPORT_FULL_01 is:
  /backup/dw/logico/expdp_full_dw1_0_210216_01.dmp
  /backup/dw/logico/expdp_full_dw1_0_210216_02.dmp
  /backup/dw/logico/expdp_full_dw1_0_210216_03.dmp
  /backup/dw/logico/expdp_full_dw1_0_210216_04.dmp
  /backup/dw/logico/expdp_full_dw1_0_210216_05.dmp
  /backup/dw/logico/expdp_full_dw1_0_210216_06.dmp
Job "SYS"."SYS_EXPORT_FULL_01" successfully completed at Sun Feb 21 02:13:13 2016 elapsed 0 00:08:10


Att,
Johab Benicio.
DBA Oracle.

