set lines 800
set long 800
set serveroutput on

begin

    for x in (select owner,db_link, username, host from dba_db_links order by 1,2) loop

        dbms_output.put_line('      ');
        dbms_output.put_line('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
        dbms_output.put_line('DDL:');
        dbms_output.put_line('SELECT dbms_metadata.get_ddl(''DB_LINK'',''' || x.db_link || ''',''' || x.owner || ''') stmt FROM dual;' );
        dbms_output.put_line('      ');
        dbms_output.put_line('Host: ');
        dbms_output.put_line(x.host);

  end loop;

end;
/


#########################################################################################################################################################


set lines 800
set long 800
set serveroutput on
define vowner = 'SYS_VETORH'

begin

    for x in (select owner,db_link, username, host from dba_db_links where owner='&vowner' order by 1,2) loop

        dbms_output.put_line('      ');
        dbms_output.put_line('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
        dbms_output.put_line('DDL:');
        dbms_output.put_line('SELECT dbms_metadata.get_ddl(''DB_LINK'',''' || x.db_link || ''',''' || x.owner || ''') stmt FROM dual;' );
        dbms_output.put_line('      ');
        dbms_output.put_line('Host: ');
        dbms_output.put_line(x.host);

  end loop;

end;
/
