Environment variables
First step is create a user and create a password: # useradd oracle
# password oracle

export JAVA_HOME=/u01/app/java
export ORACLE_HOME=/u01/app/oracle/middleware/Oracle_Home
export WL_HOME=/u01/app/oracle/middleware/Oracle_Home/wlserver


mkdir -p /u01/app/oracle/domains/
mkdir -p $JAVA_HOME
mkdir -p $ORACLE_HOME
mkdir -p $WL_HOME

Login as root user on Zlinux
• Perform the command:

#update-alternatives --install /usr/bin/java java $JAVA_HOifcon
ME/bin/java -1

• After install the alternative , now we will configurate this as default, for this perform the followed command

#update-alternatives –-config java


7.1 Installing Weblogic
First of all is necessary install the Oracle weblogic application server, for this run the command:
#java –d64 –jar fmw_12.2.1.0.0_wls.jar





chown -R oracle:oinstall /u01

## ##############################################################################
# 1 Criar usuario.
## ##############################################################################

useradd oracle
groupadd oinstall
usermod -g oinstall oracle


## ##############################################################################
# 2 Configurar o bash profiler
## ##############################################################################

vi /home/oracle/.bash_profile

export JAVA_HOME=/u01/app/oracle/java/jdk1.8.0_73
export MW_HOME=/u01/app/oracle/middleware
export ORACLE_HOME=$MW_HOME/Oracle_Home
export WL_HOME=$ORACLE_HOME/wlserver
export NODEMGR_HOME=/u01/app/oracle/domains/wl_domain/nodemanager
export DOMAIN_HOME=/u01/app/oracle/domains/wl_domain



mkdir -p $JAVA_HOME
mkdir -p $MW_HOME


## ##############################################################################
# 3 Configurar o /etc/hosts
## ##############################################################################

127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6

172.16.28.136   weblogic.com    weblogic
172.16.28.137   wlms01.com      wlms01
172.16.28.138   wlms02.com      wlms02


## ##############################################################################
# 4 Configurar o SUDO
## ##############################################################################

vi /etc/sudoers

oracle    ALL=(ALL)       ALL


## ##############################################################################
# 4 Configurar o SUDO
## ##############################################################################

tar -xvf jdk-8u73-linux-x64.tar.gz
mv jdk1.8.0_73 $JAVA_HOME

sudo update-alternatives --install /usr/bin/java java $JAVA_HOME/bin/java -1
sudo update-alternatives --config java

## ##############################################################################
# 5 Instalar o WebLogic
## ##############################################################################

java -jar -d64 fmw_12.2.1.0.0_wls.jar




## ##############################################################################
# 6 Criar arquivo de boot
## ##############################################################################

cd $DOMAIN_HOME/wl_domain/servers/AdminServer/
mkdir security
cd security


cat <<EOF>boot.properties
username=weblogic
password=welcome1
EOF


## ##############################################################################
# 5 Instalar o WebLogic
## ##############################################################################






nohup sh /u01/app/oracle/middleware/Oracle_Home/wlserver/server/bin/startNodeManager.sh





/u01/app/oracle/domains/wl_domain/security




JAVA Memory arguments: -Xms256m -Xmx512m


vde.home = /u01/app/oracle/domains/wl_domain/servers/AdminServer/data/ldap
weblogic.Name = AdminServer
weblogic.ProductionModeEnabled = true
weblogic.home = /u01/app/oracle/middleware/Oracle_Home/wlserver/server
wls.home = /u01/app/oracle/middleware/Oracle_Home/wlserver/server





WL_HOME="/u01/app/oracle/middleware/Oracle_Home/wlserver"
export WL_HOME