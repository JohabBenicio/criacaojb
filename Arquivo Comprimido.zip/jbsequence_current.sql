-- -----------------------------------------------------------------------------------
-- Autor           : Johab Benicio de Oliveira.
-- -----------------------------------------------------------------------------------

SELECT
	UPPER(I.INSTANCE_NAME) INSTANCE_NAME,
	SUBSTR(D.OPEN_MODE,1,11) "OPEN MODE",
	H.THREAD#,
	max(H.SEQUENCE#) "SEQUENCE#"
FROM
	V$LOG_HISTORY H,
	V$INSTANCE I,
	V$DATABASE D
WHERE
	H.THREAD# IN (1,2) AND
	H.FIRST_TIME>sysdate-1
group by I.INSTANCE_NAME,D.OPEN_MODE,H.THREAD#
ORDER BY 3;

