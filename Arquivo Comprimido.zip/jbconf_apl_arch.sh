

========================================================================================================================================
========================================================================================================================================
==================================================     APLICA ARCHIVE VIA RMAN    ======================================================
========================================================================================================================================
========================================================================================================================================



rm -f /tmp/jbconf_apl_arch.sh

vi /tmp/jbconf_apl_arch.sh
i

read -p "Informe o nome da instancia: " ORACLE_SID
read -p "Informe onde se encontra as pecas de backup: " DIR_BKP

read -p "Find TNSNAMES? Sim (1): " FINDTNS

if [ ! -z "$FINDTNS" ] && [ "$FINDTNS" -eq "1" ] 2>/dev/null ; then

echo -e "\n"

find $ORACLE_BASE -name tnsnames.ora 2>>/dev/null | grep -vi "samples" | while read tnsnames
do
cat $tnsnames | grep '=' -1 | grep -vi 'EXTPROC_CONNECTION_DATA\|DESCRIPTION\|ADDRESS_LIST\|ADDRES\|CONNECT_DATA\|(\|)' | sed "s/=//"
done

echo -e "\n"

fi

read -p "Informe o TNS do producao: " TNS_STD

read -p "Informe a senha do owner sys \"producao\": " PASS


if [ -d "$ORACLE_BASE/admin/$ORACLE_SID/scripts" ]; then
    export STDB_HOME=$ORACLE_BASE/admin/$ORACLE_SID/scripts/standby
    mkdir -p $STDB_HOME/log 2>>/dev/null

elif [ -d "$ORACLE_BASE/admin/$ORACLE_SID/script" ]; then
    export STDB_HOME=$ORACLE_BASE/admin/$ORACLE_SID/script/standby
    mkdir -p $STDB_HOME/log 2>>/dev/null

else
    export STDB_HOME=$ORACLE_BASE/admin/$ORACLE_SID/scripts/standby
    mkdir -p $STDB_HOME/log 2>>/dev/null

fi



cat <<JHB> $STDB_HOME/AplArch.sh

#!/bin/bash
# Teor Tecnologia Orientada
# Rua Carneiro da Cunha, 167 - cj. 105
# (11) 3797-8299
# São Paulo - SP
#
# Efetua implementação dos archives no standby
#
# Versao para Linux
# $1 ORACLE_SID

#
# Inicio
#

export ORACLE_BASE=$ORACLE_BASE
export ORACLE_HOME=$ORACLE_HOME
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib;
export PATH=$PATH

BANCO=\`ps -ef | grep smon | grep \$1 2>>/dev/null | sed 's/.*mon_\(.*\)\$/\1/' | grep -E "(^| )\$1( |$)"\`

if [ "\$1" = '' ]; then
   echo -e "\n\nDigite: sh AplArch.sh <SID> ou AplArch.sh <SID>\n\n" 
   exit
elif [ "\$BANCO" = "\$1" ]; then
   export ORACLE_SID=\$BANCO
else
   echo "Banco nao existe" 
   exit
fi

# Variaveis Globais

export STDB_HOME=$STDB_HOME
export NLS_LANG="AMERICAN_AMERICA.WE8ISO8859P1"
export STDB_DATA='date +%d%m%Y_%T'
export LOGSTAND=\$STDB_HOME/log/recover_\$ORACLE_SID.log

export STDB_CTL=\$STDB_HOME/catalog_stand.rcv
export STDB_RCV=\$STDB_HOME/recover_stand.rcv
export STDB_DEL=\$STDB_HOME/del_arch.rcv

export STDB_DIR_BKP=$DIR_BKP

export STDB_START=\$(ps -ef | grep "\$STDB_RCV\|\$STDB_DEL" | grep -v grep | wc -l )

find \$STDB_DIR_BKP -mtime +2 -exec rm -f {} \;

if [ "\$STDB_START" -gt "0" ]
then
   echo -e "\nA sincronizacao ja esta ativa! Saindo - \`$STDB_DATA\` ..."  >>\$LOGSTAND
   exit;
fi

echo -e "\n\n::Inicio da Atualizacao do banco de dados \`date +%d/%m/%Y-%T\`\n" >>\$LOGSTAND

if [ ! -e "\$STDB_CTL" ]; then
cat <<EOF> \$STDB_CTL
  run{
    allocate channel c1 device type disk;
    catalog start with '\$STDB_DIR_BKP' noprompt;
    release channel c1;
  }  
EOF
fi

if [ ! -e "\$STDB_RCV" ]; then
cat <<EOF> \$STDB_RCV
  run{
    allocate channel c1 device type disk;
    recover database delete archivelog;
    release channel c1;
  }  
EOF
fi

if [ ! -e "\$STDB_DEL" ]; then
cat <<EOF> \$STDB_DEL
  run{
    allocate channel c1 device type disk;
    Crosscheck Backup ;
    Crosscheck Archivelog all;   
    Crosscheck Copy ;
    delete noprompt obsolete;
    delete noprompt backup;
    delete noprompt archivelog all;
    release channel c1;
  }  
EOF

fi


rman target \'/ as sysdba \' cmdfile \$STDB_CTL

sleep 30

rman target \'/ as sysdba \' cmdfile \$STDB_RCV 
rman target \'/ as sysdba \' cmdfile \$STDB_DEL 



function producao {
sqlplus -S sys/$PASS@'$TNS_STD as sysdba' <<EOF

set serveroutput on
set feedback off;
declare
   x numeric(10);
begin
   SELECT SEQUENCE# into x FROM V\\\$LOG_HISTORY WHERE TO_CHAR(FIRST_TIME,'DD/MM/YYYY HH24:MI:SS')=(SELECT TO_CHAR(MAX(FIRST_TIME),'DD/MM/YYYY HH24:MI:SS') FROM V\\\$LOG_HISTORY );
   dbms_output.put_line(x);
end;
/
exit
EOF
}

function standby {

sqlplus -S /nolog <<EOF
conn / as sysdba
set feedback off;
set serveroutput on
declare
   x numeric(10);
begin
   SELECT SEQUENCE# into x FROM V\\\$LOG_HISTORY WHERE TO_CHAR(FIRST_TIME,'DD/MM/YYYY HH24:MI:SS')=(SELECT TO_CHAR(MAX(FIRST_TIME),'DD/MM/YYYY HH24:MI:SS') FROM V\\\$LOG_HISTORY );
   dbms_output.put_line(x);
end;
/
exit
EOF
}


PRD=\$(producao)
STD=\$(standby)

RESULTADO=\$(expr \$PRD - \$STD )
echo -e "ARCHIVE PROD: \$PRD"  >>\$LOGSTAND
echo "ARCHIVE STANDBY: \$STD"  >>\$LOGSTAND
echo -e "Diferenca de archives \$RESULTADO."  >>\$LOGSTAND


exit


JHB

chmod 755 $STDB_HOME/AplArch.sh

cat <<FFF

##################################################################################################################################
#                                              TEOR TECNOLOGIA ORIENTADA                                                         #
#                                                ROTINA DE SINCRONISMO                                                           #
##################################################################################################################################
# Implementado em, `date +"%d %B de %Y"`.            
# Johab Benicio de Oliveira                    
# DBA Oracle - TEOR                            
# 
#+------------------------------------------------------------------------------------------------------------------------------+
## APLICA ARCHIVE                                                                                                               |
#+------------------------------------------------------------------------------------------------------------------------------+
## BANCO ORCL                          
#+------------------------------------------------------------------------------------------------------------------------------+
# Minute Hour   MonthDay  Month  Weekday Command
# ------ ------ --------- ------ ------- ---------------------------------------------------------------------------------------+
  */30   *      *         *      *       $STDB_HOME/AplArch.sh $ORACLE_SID 1> /dev/null 2> /dev/null

FFF



:wq!






