export HOR=6
export VTMP=$(echo $HOR*60 | bc)
adrci exec="show home" | grep -v "Homes:" | while read homes
do
echo "set home $homes; purge -age $VTMP -type alert; purge -age $VTMP -type trace"
done
