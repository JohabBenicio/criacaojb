#-- -----------------------------------------------------------------------------------------
#-- Autor               : Johab Benicio de Oliveira.
#-- Descrição           : Realiza a limpeza dos traces, alertas e audit files para Oracle 11G
#-- Nome do arquivo     : ClearLogs.sh
#-- Data de criação     : 11/11/2015
#-- Data de atualização : 07/01/2016
#-- -----------------------------------------------------------------------------------------

cat <<EOF>/tmp/ClearLogs11g.sh
#!/bin/bash

if [ -f ~/.bash_profile ]; then
. ~/.bash_profile;
elif [ ~/.profile ]; then
. ~/.profile
fi

cat <<JHB
Antes da limpeza:
JHB

case \$(uname) in
"AIX") df -g;;
"Linux") df -hPT | column -t;;
*) dbf;;
esac

if [ ! -z "\$1" ] && [ "\$1" > "0" ]; then
export HOR=\$1
export VTMP=\$(echo \$HOR*60 | bc)
adrci exec="show home" | grep -v "Homes:" | while read homes
do
adrci exec="set home \$homes; purge -age \$VTMP -type alert"
adrci exec="set home \$homes; purge -age \$VTMP -type trace"
done

if [ ! -z "\$ORACLE_BASE" ]; then

ps -ef | grep smon | grep -v opuser | grep -v -i "osysmond.bin\|grep" | sed 's/.*mon_\(.*\)\$/\1/'| while read instance
do
VSID=\$(echo \$instance | sed "s/\$(echo \$instance | rev | cut -c 1)//")
DIR1=\$ORACLE_BASE/admin/\$instance
DIR2=\$ORACLE_BASE/admin/\$VSID

if [ -e "\$DIR1" ]; then
find \$DIR1/adump/ -name "*.aud" -type f -mmin +\$VTMP -exec rm -f {} \; 2>/dev/null
fi
if [ -e "\$DIR2" ]; then
find \$DIR2/adump/ -name "*.aud" -type f -mmin +\$VTMP -exec rm -f {} \; 2>/dev/null
fi

done
fi
else
echo -e "\n\nDigite \$0 HORAS ou sh \$0 HORAS \n\n"
fi
echo -e "\n"

cat <<JHB

Depois da limpeza:
JHB
case \$(uname) in
"AIX") df -g;;
"Linux") df -hPT | column -t;;
*) dbf;;
esac


EOF

chmod +x /tmp/ClearLogs11g.sh


cat <<EOF

#
#+------------------------------------------------------------------------------------------------------------------------------------------------+
## Limpeza de Logs                                                                                                                                |
#+------------------------------------------------------------------------------------------------------------------------------------------------+
# Minute Hour MonthDay  Month  Weekday   Command
# ------ ---- --------- ------ --------- ---------------------------------------------------------------------------------------------------------+
  00     02   *         *      *         $ORACLE_BASE/admin/scripts/ClearLogs11g.sh 168 > $ORACLE_BASE/admin/scripts/log/ClearLogs.log

EOF


