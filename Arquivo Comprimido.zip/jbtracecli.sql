-- -----------------------------------------------------------------------------------
-- Autor               : Johab Benicio de Oliveira.
-- Descricao           : Ativar e desativar trace de uma outra sessao
-- Nome do arquivo     : jbtracecli.sql
-- Data de criacao     : 11/06/2014
-- Data de atualização : 30/04/2015
-- -----------------------------------------------------------------------------------
/*
	OWNER_DB_OR_SO_OR_TERMINAL : Informe o nome do usuario que esta conectado no banco de dados, ou nome do usuario que esta conectado no S.O., ou o nome do Terminal.
	TEMPO_DE_CONEXAO_EM_MINUT: Informe o tempo que o usuario conectou (nos ultimos "5" minutos).
*/
SET SERVEROUTPUT ON
ALTER SESSION SET NLS_DATE_FORMAT='DD-MM-YYYY HH24:MI:SS';
SET LINES 200
set long 999
col SQL_TEXT for a180

DECLARE
	V_VAR_QUERY VARCHAR2(30) := '&OWNER_OSUSER_TERMINAL_SID';
	V_1T NUMERIC(20) := '&TEMPO_DE_CONEXAO_EM_MINUT';
	V_1DATE varchar2(20);
	v_1Y varchar2(10);
	v_2Y varchar2(10);
	v_3Y varchar2(90);
	v_4Y varchar2(90);
	JBQB VARCHAR2(2) := CHR(13) || CHR(10);
	v_isnt varchar2(10);
BEGIN

	select VALUE into v_3Y from v$parameter where NAME like '%user_dump_dest%' ;
	select lower(instance_name) into v_isnt from v$instance;

	select to_char(sysdate,'dd/mm/yyyy hh24:mi:ss') into V_1DATE from dual;
	dbms_output.put_line( JBQB || JBQB );
	V_1T:=V_1T*60;

		FOR X IN ( SELECT INST_ID, SID, SERIAL#, USERNAME, LOGON_TIME, MACHINE, OSUSER, STATUS, SQL_HASH_VALUE, TERMINAL,PROGRAM FROM GV$SESSION
			WHERE USERNAME = UPPER(V_VAR_QUERY) AND LAST_CALL_ET < V_1T
			or (SID = UPPER(V_VAR_QUERY) and USERNAME is not null) AND LAST_CALL_ET < V_1T
			ORDER BY LOGON_TIME ASC
		)LOOP

			for y in (select distinct spid from gv$process p, gv$session s where p.addr = s.paddr and s.sid  = X.SID) loop
				v_4Y:=y.spid;

				DBMS_OUTPUT.PUT_LINE('========================================================================================================================');
				DBMS_OUTPUT.PUT_LINE('DATABASE INFORMATION:');
				DBMS_OUTPUT.PUT_LINE('SID:.............................. ' || X.SID);
				DBMS_OUTPUT.PUT_LINE('SERIAL#:.......................... ' || X.SERIAL#);
				DBMS_OUTPUT.PUT_LINE('OWNER OF THE DATABASE:............ ' || X.USERNAME);
				DBMS_OUTPUT.PUT_LINE('STATUS:........................... ' || X.STATUS);
				DBMS_OUTPUT.PUT_LINE('INSTANCE ID:...................... ' || 'NODE ' || X.INST_ID);

				if X.SQL_HASH_VALUE <> 0 then
				DBMS_OUTPUT.PUT_LINE('LOGON TIME:....................... ' || X.LOGON_TIME);
				DBMS_OUTPUT.PUT_LINE('QUERY TEXT:....................... SELECT SQL_TEXT FROM V$SQL WHERE HASH_VALUE=' || X.SQL_HASH_VALUE || ';' || JBQB);
				else
				DBMS_OUTPUT.PUT_LINE('LOGON TIME:....................... ' || X.LOGON_TIME || JBQB);
				end if;

				DBMS_OUTPUT.PUT_LINE('FORMA DE CONEXAO (programa usado):');
  				DBMS_OUTPUT.PUT_LINE('SESSION PROGRAM:.................. ' || X.PROGRAM || JBQB);

				DBMS_OUTPUT.PUT_LINE('S.O INFORMATION:');
				DBMS_OUTPUT.PUT_LINE('PID:.............................. ' || v_4Y);
				DBMS_OUTPUT.PUT_LINE('OWNER OF THE S.O:................. ' || X.OSUSER);
				DBMS_OUTPUT.PUT_LINE('MACHINE:.......................... ' || X.MACHINE);
				DBMS_OUTPUT.PUT_LINE('TERMINAL:......................... ' || X.TERMINAL || JBQB);

				DBMS_OUTPUT.PUT_LINE('ATIVAR E DASATIVAR TRACE:');
				DBMS_OUTPUT.PUT_LINE('ATIVAR TRACE...................... EXEC SYS.DBMS_SYSTEM.SET_EV('||X.SID||','||X.SERIAL#||',10046,12,'''');');
				DBMS_OUTPUT.PUT_LINE('.................................. EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE('||X.SID||','||X.SERIAL#||',TRUE,TRUE);'||chr(10));

				DBMS_OUTPUT.PUT_LINE('DESATIVAR TRACE................... EXEC SYS.DBMS_SYSTEM.SET_EV('||X.SID||','||X.SERIAL#||',10046,0,'''');');
				DBMS_OUTPUT.PUT_LINE('.................................. EXEC DBMS_MONITOR.SESSION_TRACE_DISABLE('||X.SID||','||X.SERIAL#||');'||JBQB);
				DBMS_OUTPUT.PUT_LINE('NOME DO TRACE:.................... ' || v_3Y || '/' || v_isnt || '_ora_' || v_4Y || '.trc');
				DBMS_OUTPUT.PUT_LINE('HORARIO ATUAL:.................... ' || V_1DATE);
--				DBMS_OUTPUT.PUT_LINE('SEGUNDOS:......................... ' || V_1T);
				DBMS_OUTPUT.PUT_LINE('========================================================================================================================' || JBQB);
			END LOOP;
		END LOOP;

dbms_output.put_line('10046 Trace levels');
dbms_output.put_line('...  0 - Nenhum traco. Como mudar sql_trace off.');
dbms_output.put_line('...  2 - O equivalente a sql_trace regular.');
dbms_output.put_line('...  4 - O mesmo que 2, mas com a adicao de valores de variaveis de ligacao.');
dbms_output.put_line('...  8 - O mesmo que 2, mas com a adicao de eventos de espera.');
dbms_output.put_line('... 12 - O mesmo que 2, mas com tanto vincular os valores das variaveis e eventos de espera.');

EXCEPTION
  WHEN OTHERS THEN

    FOR X IN ( SELECT INST_ID, SID, SERIAL#, USERNAME, LOGON_TIME, MACHINE, OSUSER, STATUS, SQL_HASH_VALUE, TERMINAL,PROGRAM FROM GV$SESSION
			WHERE USERNAME = UPPER(V_VAR_QUERY) AND LAST_CALL_ET < V_1T
			or ((TERMINAL = UPPER(V_VAR_QUERY) or TERMINAL = LOWER(V_VAR_QUERY)) and USERNAME is not null) AND LAST_CALL_ET < V_1T
			or ((UPPER(OSUSER) = UPPER(V_VAR_QUERY) ) and USERNAME is not null) AND LAST_CALL_ET < V_1T
			ORDER BY LOGON_TIME ASC
		)LOOP

			for y in (select distinct spid from gv$process p, gv$session s where p.addr = s.paddr and s.sid  = X.SID) loop
				v_4Y:=y.spid;

				DBMS_OUTPUT.PUT_LINE('========================================================================================================================');
				DBMS_OUTPUT.PUT_LINE('DATABASE INFORMATION:');
				DBMS_OUTPUT.PUT_LINE('SID:.............................. ' || X.SID);
				DBMS_OUTPUT.PUT_LINE('SERIAL#:.......................... ' || X.SERIAL#);
				DBMS_OUTPUT.PUT_LINE('OWNER OF THE DATABASE:............ ' || X.USERNAME);
				DBMS_OUTPUT.PUT_LINE('STATUS:........................... ' || X.STATUS);
				DBMS_OUTPUT.PUT_LINE('INSTANCE ID:...................... ' || 'NODE ' || X.INST_ID);

				if X.SQL_HASH_VALUE <> 0 then
				DBMS_OUTPUT.PUT_LINE('LOGON TIME:....................... ' || X.LOGON_TIME);
				DBMS_OUTPUT.PUT_LINE('QUERY TEXT:....................... SELECT SQL_TEXT FROM V$SQL WHERE HASH_VALUE=' || X.SQL_HASH_VALUE || ';' || JBQB);
				else
				DBMS_OUTPUT.PUT_LINE('LOGON TIME:....................... ' || X.LOGON_TIME || JBQB);
				end if;

				DBMS_OUTPUT.PUT_LINE('FORMA DE CONEXAO (programa usado):');
  				DBMS_OUTPUT.PUT_LINE('SESSION PROGRAM:.................. ' || X.PROGRAM || JBQB);

				DBMS_OUTPUT.PUT_LINE('S.O INFORMATION:');
				DBMS_OUTPUT.PUT_LINE('PID:.............................. ' || v_4Y);
				DBMS_OUTPUT.PUT_LINE('OWNER OF THE S.O:................. ' || X.OSUSER);
				DBMS_OUTPUT.PUT_LINE('MACHINE:.......................... ' || X.MACHINE);
				DBMS_OUTPUT.PUT_LINE('TERMINAL:......................... ' || X.TERMINAL || JBQB);

				DBMS_OUTPUT.PUT_LINE('ATIVAR E DASATIVAR TRACE:');
				DBMS_OUTPUT.PUT_LINE('ATIVAR TRACE...................... EXEC SYS.DBMS_SYSTEM.SET_EV('||X.SID||','||X.SERIAL#||',10046,12,'''');');
				DBMS_OUTPUT.PUT_LINE('.................................. EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE('||X.SID||','||X.SERIAL#||',TRUE,TRUE);'||chr(10));

				DBMS_OUTPUT.PUT_LINE('DESATIVAR TRACE................... EXEC SYS.DBMS_SYSTEM.SET_EV('||X.SID||','||X.SERIAL#||',10046,0,'''');');
				DBMS_OUTPUT.PUT_LINE('.................................. EXEC DBMS_MONITOR.SESSION_TRACE_DISABLE('||X.SID||','||X.SERIAL#||');'||JBQB);
				DBMS_OUTPUT.PUT_LINE('NOME DO TRACE:.................... ' || v_3Y || '/' || v_isnt || '_ora_' || v_4Y || '.trc');
				DBMS_OUTPUT.PUT_LINE('HORARIO ATUAL:.................... ' || V_1DATE);
--				DBMS_OUTPUT.PUT_LINE('SEGUNDOS:......................... ' || V_1T);
				DBMS_OUTPUT.PUT_LINE('========================================================================================================================' || JBQB);
			END LOOP;
		END LOOP;

END;
/
